# Python Package Sample

This is a simple example package create for a 42 project.